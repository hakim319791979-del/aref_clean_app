import '../models/country.dart';

class MockDataService {
  const MockDataService();

  static const List<Country> _countries = [
    Country(
      code: 'TR',
      nameAr: 'تركيا',
      nameEn: 'Türkiye',
      laws: 'الإقامة والعمل والمرور.',
      customs: 'السلام الرسمي وخلع الحذاء في البيوت.',
      safety: 'آمن عموماً. احذر النصب السياحي.',
      costs: 'إسطنبول أعلى من غيرها. النقل العام مقبول.',
    ),
    Country(
      code: 'DE',
      nameAr: 'ألمانيا',
      nameEn: 'Germany',
      laws: 'صرامة في الضرائب والمرور.',
      customs: 'دقة المواعيد واحترام الخصوصية.',
      safety: 'مرتفع.',
      costs: 'السكن مرتفع في المدن الكبرى.',
    ),
  ];

  List<Country> list() => List.unmodifiable(_countries);

  List<Country> search(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return list();
    return _countries.where((c) =>
      c.nameAr.contains(query) ||
      c.nameEn.toLowerCase().contains(q) ||
      c.code.toLowerCase() == q
    ).toList(growable: false);
  }

  List<Map<String, String>> contributions(String countryCode) {
    if (countryCode.isEmpty) return const [];
    final now = DateTime.now().toIso8601String();
    return [
      {'user': 'ضيف', 'text': 'حمّل İstanbulkart من المطار.', 'timestamp': now},
      {'user': 'Guest', 'text': 'Keep small cash for bakeries.', 'timestamp': now},
    ];
  }

  List<Map<String, Object>> congestion(String city) {
    return const [
      {'district': 'Fatih', 'index': 72},
      {'district': 'Beyoglu', 'index': 65},
      {'district': 'Kadikoy', 'index': 58},
      {'district': 'Basaksehir', 'index': 44},
    ];
  }
}
