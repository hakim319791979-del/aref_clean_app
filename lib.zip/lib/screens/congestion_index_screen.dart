// ignore_for_file: prefer_const_constructors
import 'package:flutter/material.dart';
import '../services/mock_data.dart';

class CongestionIndexScreen extends StatelessWidget {
  const CongestionIndexScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final data = const MockDataService().congestion('Istanbul');
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('مؤشر ازدحام الأحياء')),
        body: ListView.builder(
          itemCount: data.length,
          itemBuilder: (ctx, i) {
            final row = data[i];
            return ListTile(
              title: Text('${row['district']}'),
              trailing: Text('${row['index']}'),
            );
          },
        ),
      ),
    );
  }
}
