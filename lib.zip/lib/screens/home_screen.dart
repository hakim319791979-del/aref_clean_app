// ignore_for_file: prefer_const_constructors
import 'package:flutter/material.dart';
import '../services/mock_data.dart';
import 'country_detail_screen.dart';
import 'contribute_screen.dart';
import 'congestion_index_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _svc = const MockDataService();
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final results = _svc.search(_query);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('اعرف قبل أن تسافر')),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: TextField(
                decoration: const InputDecoration(
                  hintText: 'ابحث عن دولة...',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.search),
                ),
                onChanged: (v) => setState(() => _query = v),
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: results.length,
                itemBuilder: (context, i) {
                  final c = results[i];
                  return Card(
                    child: ListTile(
                      title: Text(c.nameAr),
                      subtitle: Text(c.nameEn),
                      trailing: const Icon(Icons.chevron_left),
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(
                          builder: (_) => CountryDetailScreen(country: c),
                        ));
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
        floatingActionButton: _fab(context),
      ),
    );
  }

  Widget _fab(BuildContext context) {
    return PopupMenuButton<String>(
      icon: const Icon(Icons.add),
      onSelected: (val) {
        if (val == 'contribute') {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const ContributeScreen()));
        } else if (val == 'congestion') {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const CongestionIndexScreen()));
        }
      },
      itemBuilder: (ctx) => const [
        PopupMenuItem(
          value: 'contribute',
          child: Row(children: [Icon(Icons.edit), SizedBox(width: 8), Text('مساهمة المستخدمين')]),
        ),
        PopupMenuItem(
          value: 'congestion',
          child: Row(children: [Icon(Icons.map), SizedBox(width: 8), Text('مؤشر ازدحام الأحياء')]),
        ),
      ],
    );
  }
}
