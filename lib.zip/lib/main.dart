// ignore_for_file: prefer_const_constructors
import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.dumpErrorToConsole(details);
  };
  PlatformDispatcher.instance.onError = (error, stack) {
    debugPrint('Platform error: $error');
    return true;
  };

  runZonedGuarded(() {
    runApp(const ArefApp());
  }, (error, stack) {
    debugPrint('Zone error: $error');
  });
}

class ArefApp extends StatelessWidget {
  const ArefApp({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = ThemeData(
      useMaterial3: true,
      colorSchemeSeed: const Color(0xFF006E7F),
      brightness: Brightness.light,
    );

    ErrorWidget.builder = (details) => Material(
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Text(
            'Error: ${details.exception}',
            textDirection: TextDirection.ltr,
          ),
        ),
      ),
    );

    return MaterialApp(
      title: 'اعرف قبل أن تسافر',
      theme: theme,
      debugShowCheckedModeBanner: false,
      home: const HomeScreen(),
      supportedLocales: const [Locale('ar'), Locale('en')],
    );
  }
}
